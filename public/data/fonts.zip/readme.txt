readme

index.txt = info über die Schrift

die fonts werden einfach auf "font-" und dessen schnitt "regular" ect. benannt
soll eine neue schrift reingeladen werden, so kann man diese dann einfach Versetzen

bitte datei-format beachten (ttf,otf ect.)
